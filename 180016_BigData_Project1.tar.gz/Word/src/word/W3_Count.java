package word;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class W3_Count {
	//mapper class
	public static class MapForWordCount extends Mapper<LongWritable,Text,Text,IntWritable>
	{
		public void map(LongWritable key,Text value, Context con) throws IOException, InterruptedException
		{
			String line= value.toString();
			String[] words=line.split(",");
			Text outputkey=new Text(words[3]);
			IntWritable outputvalue=new IntWritable(1);
			con.write(outputkey,outputvalue);	
		}
	}
	
	public static <K, V extends Comparable<V> > Map.Entry<K, V> 
    getMaxEntryInMapBasedOnValue(Map<K, V> map) 
    { 
        // To store the result 
        Map.Entry<K, V> entryWithMaxValue = null; 
  
        // Iterate in the map to find the required entry 
        for (Map.Entry<K, V> currentEntry : map.entrySet()) { 
  
            if ( 
                // If this is the first entry, set result as this 
                entryWithMaxValue == null
  
                // If this entry's value is more than the max value 
                // Set this entry as the max 
                || currentEntry.getValue() 
                           .compareTo(entryWithMaxValue.getValue()) 
                       > 0) { 
  
                entryWithMaxValue = currentEntry; 
            } 
        } 
  
        // Return the entry with highest value 
        return entryWithMaxValue; 
    } 
  
	
	//reducer class
	public static class ReduceForWordCount extends Reducer<Text,IntWritable,Text,IntWritable>
	{
		Map<Text, IntWritable> map
		= new HashMap<>();
		public void reduce(Text word,Iterable<IntWritable> values,Context con)throws IOException, InterruptedException
		{
			int sum=0;
			for(IntWritable value:values)
			{
				sum=sum+value.get();
			}
			map.put(word,new IntWritable(sum));
			getMaxEntryInMapBasedOnValue(map);
			Text w1= getMaxEntryInMapBasedOnValue(map).getKey();
			IntWritable w2= getMaxEntryInMapBasedOnValue(map).getValue();
			con.write(w1, w2);
		}
		
	}
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		Configuration c= new Configuration();
		Job j=Job.getInstance(c,"wordcount");
		j.setJarByClass(W3_Count.class);
		j.setMapperClass(MapForWordCount.class);
		j.setReducerClass(ReduceForWordCount.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(j,new Path(args[0]));
		FileOutputFormat.setOutputPath(j,new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
		
	}
	

}
